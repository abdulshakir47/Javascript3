// SetInterval and setTimeout In js

var counter = document.querySelector(".counter")
var followers = document.querySelector(".followers")

count = 1

setInterval(()=>{
    if(count < 1000){
        count++;
        counter.innerText = count;
    }
},1)

setTimeout(()=>{
    followers.innerText = "Followers On instagram!"
},6300)