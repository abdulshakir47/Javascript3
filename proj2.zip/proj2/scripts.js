const red = document.querySelector(".red");
const cyan = document.querySelector(".cyan");
const violet = document.querySelector(".violet");
const orange = document.querySelector(".orange");
const pink = document.querySelector(".pink");
const center = document.querySelector(".center")

const getBgColor = (selectelement)=>{
    return window.getComputedStyle(selectelement).backgroundColor;
}

// var orangeElementColor = getBgColor(orange)



const magicChanger = (element,color)=>{
    return element.addEventListener("mouseenter",()=>{
        center.style.background = color;
    })
}

magicChanger(red,getBgColor(red))
magicChanger(cyan,getBgColor(cyan))
magicChanger(violet,getBgColor(violet))
magicChanger(orange,getBgColor(orange))
magicChanger(pink,getBgColor(pink))